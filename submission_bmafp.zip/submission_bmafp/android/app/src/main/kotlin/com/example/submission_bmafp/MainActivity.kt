package com.example.submission_bmafp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
