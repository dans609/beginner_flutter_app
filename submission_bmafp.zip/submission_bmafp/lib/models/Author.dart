class Author {
  String authorName;

  Author({required this.authorName});
}