class Role {
  List<String> roleNames;

  Role({required this.roleNames});
}